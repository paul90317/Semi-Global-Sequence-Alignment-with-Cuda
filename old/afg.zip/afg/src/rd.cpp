#include <cstdlib>
#include <iostream>
#include <fstream>

using namespace std;

int r=0;
int myrand(){
    static int times=100000;
    if(times==100000){
        srand(r);
        r++;
        times=0;
    }else{
        times++;
    }
    return rand();
}

int main(int argc,char** argv){
    fstream fout;
    int t,count;
    char nbs[4]={'A','T','C','G'};
    if(argc!=3){
        cout<<"Follow format: command [what.txt] [count]\n";
        return 0;
    }
    count=strtol(argv[2],NULL,10);
    if(count>=5000){
        for(int i=0;i<5000;i++){
            myrand();
        }
    }
    fout.open(argv[1],ios::out);
    for(int i=0;i<count;i++){
        t=myrand()%4;
        fout<<nbs[t];
    }
    fout.close();
}